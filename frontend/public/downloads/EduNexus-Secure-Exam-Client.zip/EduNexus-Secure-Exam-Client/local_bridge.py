"""Restricted loopback bridge between an EduNexus exam page and the desktop app.

Browser pairing requires a user gesture on the authenticated exam page AND
an approval click inside the app. A localhost POST alone never starts monitoring.
"""
from __future__ import annotations

import json
import os
import ipaddress
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

PORT = 47913
LOCAL_HOST = "127.0.0.1"
DEFAULT_ORIGINS = ("http://localhost:3000", "http://127.0.0.1:3000")
MAX_BODY = 65536


# Explicit opt-in ONLY for local development over a trusted, private IPv4 LAN.
# HTTPS remains required for actual deployments. Never use Access-Control-Allow-Origin: *.
_PRIVATE_LAN = tuple(ipaddress.ip_network(net) for net in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
))


def dev_lan_http_permitted(parsed) -> bool:
    if os.environ.get("EDUNEXUS_ALLOW_LAN_HTTP") != "1" or parsed.scheme != "http":
        return False
    try:
        ip = ipaddress.ip_address(parsed.hostname or "")
        return ip.version == 4 and any(ip in network for network in _PRIVATE_LAN)
    except ValueError:
        return False


def valid_web_origin(value: str) -> bool:
    try:
        parsed = urlsplit(value)
        if (not parsed.hostname or parsed.username or parsed.password or parsed.query or
                parsed.fragment or parsed.path not in ("", "/")):
            return False
        _ = parsed.port  # Also reject malformed ports.
        return parsed.scheme == "https" or dev_lan_http_permitted(parsed)
    except ValueError:
        return False


def allowed_origins() -> frozenset[str]:
    # The operator must specify the exact origin; we never trust an arbitrary LAN website.
    extra = [o.strip().rstrip("/") for o in os.environ.get("EDUNEXUS_WEB_ORIGINS", "").split(",") if o.strip()]
    return frozenset((*DEFAULT_ORIGINS, *(o for o in extra if valid_web_origin(o))))


def valid_request(data: object) -> bool:
    if not isinstance(data, dict):
        return False
    code = data.get("pair_code")
    raw_server = data.get("server")
    if not isinstance(code, str) or not re.fullmatch(r"[a-fA-F0-9]{64}", code):
        return False
    if not isinstance(raw_server, str) or len(raw_server) > 250:
        return False
    url = urlsplit(raw_server)
    try:
        _ = url.port
    except ValueError:
        return False
    if url.username or url.password or url.query or url.fragment or url.path not in ("", "/"):
        return False
    return bool((url.scheme == "https" and url.hostname) or
                (url.scheme == "http" and url.hostname in ("localhost", "127.0.0.1", "::1")) or
                dev_lan_http_permitted(url))


class BridgeServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, callback, test_runs=None):
        self.test_runs = test_runs
        super().__init__((LOCAL_HOST, PORT), BridgeHandler)
        self.callback = callback


class BridgeHandler(BaseHTTPRequestHandler):
    server: BridgeServer

    def log_message(self, *_args):
        pass  # No secrets in logs.

    def _authorized(self) -> bool:
        host = self.headers.get("Host", "")
        return (self.headers.get("Origin") in allowed_origins() and
                host == f"{LOCAL_HOST}:{PORT}")

    def _reply(self, code: int, data: dict):
        body = json.dumps(data).encode("utf-8")
        self.send_response(code)
        if self._authorized():
            self.send_header("Access-Control-Allow-Origin", self.headers["Origin"])
            self.send_header("Vary", "Origin")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        if (self.path not in ("/pair", "/health", "/test-runs") and not re.fullmatch(r"/test-runs/[a-f0-9]{64}(?:/cancel)?", self.path)) or not self._authorized():
            return self._reply(403, {"ok": False})
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", self.headers["Origin"])
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS" if self.path in ("/pair", "/test-runs") or self.path.endswith("/cancel") else "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Vary", "Origin")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def do_GET(self):
        if re.fullmatch(r"/test-runs/[a-f0-9]{64}", self.path) and self._authorized() and self.server.test_runs:
            job = self.server.test_runs.status(self.path.rsplit("/", 1)[1], self.headers["Origin"])
            return self._reply(200, {"ok": True, **job}) if job else self._reply(404, {"ok": False, "error": "Test run not found"})
        if self.path != "/health" or not self._authorized():
            return self._reply(403, {"ok": False})
        self._reply(200, {"ok": True, "client": "EduNexus Secure Exam", "pairing": "local-confirmation", "tester_protocol": "edunexus.tester.v1" if self.server.test_runs else None})

    def do_POST(self):
        if (self.path not in ("/pair", "/test-runs") and not re.fullmatch(r"/test-runs/[a-f0-9]{64}/cancel", self.path)) or not self._authorized():
            return self._reply(403, {"ok": False, "error": "not_allowed"})
        if self.headers.get("Content-Type", "").split(";")[0].strip().lower() != "application/json":
            return self._reply(415, {"ok": False})
        try:
            length = int(self.headers.get("Content-Length", "-1"))
            if not 0 < length <= MAX_BODY:
                return self._reply(413, {"ok": False})
            data = json.loads(self.rfile.read(length))
        except (ValueError, UnicodeDecodeError):
            return self._reply(400, {"ok": False})
        if self.path.endswith("/cancel"):
            job_id = self.path.split("/")[2]
            if not self.server.test_runs or not self.server.test_runs.status(job_id, self.headers["Origin"]):
                return self._reply(404, {"ok": False})
            self.server.test_runs.reject(job_id)
            return self._reply(200, {"ok": True})
        if self.path == "/test-runs":
            if not self.server.test_runs:
                return self._reply(409, {"ok": False, "error": "Update the desktop client to run tests"})
            try:
                job = self.server.test_runs.create(data, self.headers["Origin"])
                return self._reply(202, {"ok": True, **job})
            except ValueError as exc:
                return self._reply(400, {"ok": False, "error": str(exc)})
        if not valid_request(data):
            return self._reply(400, {"ok": False, "error": "invalid_pair"})
        if not self.server.callback(data):
            return self._reply(409, {"ok": False, "error": "client_busy"})
        self._reply(200, {"ok": True, "status": "awaiting_user_approval"})


class DesktopPairingBridge:
    def __init__(self, callback, test_runs=None):
        self.httpd = BridgeServer(callback, test_runs)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def start(self):
        self.thread.start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=2)
